//the language int (for greek 2)
extern int _language_;
//the Start's int (not to have any problem with the Live Earth wallpaper (1 if running)
extern int _start_running_;
extern int _live_earth_running_;
extern int minimize_to_tray;
extern int pref;
